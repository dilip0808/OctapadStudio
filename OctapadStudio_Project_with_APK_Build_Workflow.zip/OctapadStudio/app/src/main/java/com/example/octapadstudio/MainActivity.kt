package com.example.octapadstudio

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import java.io.IOException
import java.net.Socket
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var log: TextView
    private lateinit var editor: EditText
    private var serialPort: UsbSerialPort? = null
    private var wifiSocket: Socket? = null
    private val notes = intArrayOf(36, 38, 42, 46, 41, 43, 45, 49)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 31) {
            val needed = arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
                .filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
            if (needed.isNotEmpty()) ActivityCompat.requestPermissions(this, needed.toTypedArray(), 7)
        }
        buildUi()
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(0xFF10131B.toInt())
        }
        val title = TextView(this).apply {
            text = "OCTAPAD STUDIO  •  Pico 2 W"
            textSize = 22f; setTextColor(0xFF42D6A4.toInt())
            gravity = Gravity.CENTER; setPadding(0, 10, 0, 14)
        }
        outer.addView(title)
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val content = FrameLayout(this)
        fun tab(label: String, action: () -> Unit) {
            tabs.addView(Button(this).apply { text = label; setOnClickListener { action() } },
                LinearLayout.LayoutParams(0, -2, 1f))
        }
        tab("PADS") { showPads(content) }
        tab("REPL / CODE") { showEditor(content) }
        tab("CONNECT") { showConnect(content) }
        outer.addView(tabs)
        outer.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        log = TextView(this).apply {
            text = "Ready. Connect a Pico to begin."
            textSize = 12f; setTextColor(0xFFCBD5E1.toInt()); setPadding(8, 8, 8, 8)
        }
        outer.addView(ScrollView(this).apply { addView(log) }, LinearLayout.LayoutParams(-1, 110))
        setContentView(outer)
        showPads(content)
    }

    private fun showPads(host: FrameLayout) {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(4, 16, 4, 4) }
        val grid = GridLayout(this).apply { columnCount = 2; rowCount = 4 }
        val names = arrayOf("KICK", "SNARE", "CLOSED HAT", "OPEN HAT", "TOM 1", "TOM 2", "FLOOR TOM", "CRASH")
        names.forEachIndexed { i, name ->
            val b = Button(this).apply {
                text = "$name\nMIDI ${notes[i]}"
                textSize = 15f
                setOnClickListener { appendLog("Pad ${i + 1} hit (MIDI note ${notes[i]}). Local UI trigger only; audio/MIDI output is not yet wired.") }
            }
            grid.addView(b, GridLayout.LayoutParams().apply {
                width = 0; height = 130; columnSpec = GridLayout.spec(i % 2, 1f)
                rowSpec = GridLayout.spec(i / 2); setMargins(5, 5, 5, 5)
            })
        }
        layout.addView(grid)
        layout.addView(TextView(this).apply {
            text = "Sensitivity is calibrated in the Pico firmware. These screen pads are currently UI triggers, not an audio synthesizer."
            setTextColor(0xFFCBD5E1.toInt()); setPadding(8, 12, 8, 8)
        })
        host.removeAllViews(); host.addView(layout)
    }

    private fun showEditor(host: FrameLayout) {
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(4, 10, 4, 4) }
        editor = EditText(this).apply {
            setText("# MicroPython scratch editor\\nprint('Hello from Octapad Studio')\\n")
            gravity = Gravity.TOP; minLines = 10; textSize = 13f
            setTextColor(0xFFE2E8F0.toInt()); setHintTextColor(0xFF94A3B8.toInt())
            setBackgroundColor(0xFF1C2230.toInt())
        }
        l.addView(editor, LinearLayout.LayoutParams(-1, 0, 1f))
        l.addView(Button(this).apply {
            text = "SEND TO USB SERIAL"
            setOnClickListener { sendSerial(editor.text.toString() + "\n") }
        })
        l.addView(Button(this).apply {
            text = "SEND TO WI-FI TCP"
            setOnClickListener { sendWifi(editor.text.toString() + "\n") }
        })
        host.removeAllViews(); host.addView(l)
    }

    private fun showConnect(host: FrameLayout) {
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 12, 8, 8) }
        l.addView(Button(this).apply { text = "Find / Open USB Serial"; setOnClickListener { openUsb() } })
        val ip = EditText(this).apply { hint = "Pico TCP host IP"; setSingleLine(true); setText("192.168.4.1") }
        val port = EditText(this).apply { hint = "TCP port"; setSingleLine(true); setText("8266"); inputType = 2 }
        l.addView(ip); l.addView(port)
        l.addView(Button(this).apply {
            text = "Connect Wi-Fi TCP console"
            setOnClickListener { connectWifi(ip.text.toString(), port.text.toString().toIntOrNull() ?: 8266) }
        })
        l.addView(Button(this).apply { text = "Scan BLE devices"; setOnClickListener { scanBle() } })
        l.addView(TextView(this).apply {
            text = "BLE MIDI and RTP-MIDI are not complete in this starter. Wi-Fi TCP requires a compatible server running on the Pico."
            setTextColor(0xFFCBD5E1.toInt()); setPadding(4, 12, 4, 4)
        })
        host.removeAllViews(); host.addView(ScrollView(this).apply { addView(l) })
    }

    private fun openUsb() {
        try {
            val manager = getSystemService(Context.USB_SERVICE) as UsbManager
            val drivers = UsbSerialProber.getDefaultProber().findAllDrivers(manager)
            if (drivers.isEmpty()) { appendLog("No supported USB serial device found. Check OTG, cable, and permissions."); return }
            val driver = drivers[0]
            if (!manager.hasPermission(driver.device)) {
                appendLog("USB permission is required. Reconnect and grant permission when Android prompts; permission receiver flow must be added for some devices.")
                return
            }
            val connection = manager.openDevice(driver.device) ?: run { appendLog("Could not open USB device."); return }
            serialPort = driver.ports.first()
            serialPort!!.open(connection)
            serialPort!!.setParameters(115200, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
            appendLog("USB serial opened at 115200 baud. Serial read loop/permission flow may need adaptation for the phone and device.")
        } catch (e: Exception) { appendLog("USB error: ${e.message}") }
    }

    private fun sendSerial(s: String) {
        io.execute {
            try {
                val bytes = s.toByteArray()
                serialPort?.write(bytes, 1000) ?: throw IOException("USB serial is not connected")
                runOnUiThread { appendLog("Sent ${bytes.size} bytes over USB serial.") }
            } catch (e: Exception) { runOnUiThread { appendLog("USB send error: ${e.message}") } }
        }
    }

    private fun connectWifi(host: String, port: Int) {
        io.execute {
            try {
                wifiSocket?.close()
                wifiSocket = Socket(host, port)
                runOnUiThread { appendLog("TCP connected to $host:$port. Ensure Pico runs a matching TCP REPL server.") }
            } catch (e: Exception) { runOnUiThread { appendLog("Wi-Fi TCP error: ${e.message}") } }
        }
    }

    private fun sendWifi(s: String) {
        io.execute {
            try {
                val socket = wifiSocket ?: throw IOException("Wi-Fi TCP is not connected")
                socket.getOutputStream().write(s.toByteArray())
                socket.getOutputStream().flush()
                runOnUiThread { appendLog("Sent code over Wi-Fi TCP.") }
            } catch (e: Exception) { runOnUiThread { appendLog("Wi-Fi send error: ${e.message}") } }
        }
    }

    private fun scanBle() {
        try {
            val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            val adapter: BluetoothAdapter? = manager.adapter
            if (adapter == null || !adapter.isEnabled) { appendLog("Bluetooth is unavailable or disabled."); return }
            appendLog("Bluetooth adapter is ready. BLE scanning UI/scan callback and BLE-MIDI GATT transport must be completed and tested for your target peripheral.")
        } catch (e: SecurityException) { appendLog("Bluetooth permission not granted.") }
    }

    private fun appendLog(message: String) {
        runOnUiThread { log.append("\n$message") }
    }

    override fun onDestroy() {
        try { serialPort?.close() } catch (_: Exception) {}
        try { wifiSocket?.close() } catch (_: Exception) {}
        io.shutdownNow()
        super.onDestroy()
    }
}
