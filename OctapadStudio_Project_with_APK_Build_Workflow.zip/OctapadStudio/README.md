# Octapad Studio — Android + Pico 2 W project

This is a **new unified project** inspired by the two APKs you supplied. It does not repackage or copy their compiled internals. To preserve the original apps exactly, their original source projects are required.

## Included
- Android Studio Kotlin app with tabs for Pads, REPL/Editor, and Connections.
- Eight on-screen drum pads and configurable MIDI note numbers.
- USB host serial connection via `usb-serial-for-android`.
- Wi-Fi TCP console client (requires a matching TCP REPL server on the Pico; stock MicroPython does not expose a network REPL by default).
- BLE scan/connect scaffolding; BLE MIDI transport is explicitly experimental and not yet implemented as a complete, verified MIDI service.
- Pico MicroPython firmware for a 16-channel CD/74HC4067 multiplexer, analog piezo inputs, sensitivity calibration, pulse-width/peak estimation, and a text diagnostic stream.
- Wiring and calibration notes for two LM324 stages.

## Feature status
| Feature | Status |
|---|---|
| Android app UI, pads, editor text area, console view | Implemented in source; build/device test still required |
| USB OTG serial transport | Implemented in source using USB serial library; hardware test required |
| Wi-Fi TCP console client | Implemented in source; requires matching Pico TCP server and network setup |
| BLE device scan/connect | Implemented in source; device test required |
| BLE MIDI send/receive | Not implemented/verified in this starter project |
| RTP-MIDI (AppleMIDI) | Not implemented; requires protocol/session implementation |
| Pico 4067 scan and trigger detection | Implemented in firmware source; pin mapping and thresholds need calibration |
| LM324 analog velocity measurement | Approximation only; needs oscilloscope/meter calibration and real pad tests |
| USB MIDI from Pico to Android | Not provided by standard MicroPython USB CDC; requires custom USB MIDI firmware/descriptor support or a separate MIDI interface |
| APK | Not included; build with Android Studio/Gradle |

## Build Android app
1. Install Android Studio (recent stable) and JDK 17.
2. Open this folder as a project.
3. Let Gradle sync. Android SDK 35 is configured.
4. Build > Build APK(s). The debug APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.
5. On Android, enable OTG if your phone requires it. Use a USB OTG adapter and a USB-serial interface/CDC device supported by the serial library. A direct Pico USB CDC connection may need the CDC driver path verified on your device.

## Firmware install
1. Flash Raspberry Pi Pico 2 W with a compatible MicroPython UF2 for Pico 2 W.
2. In Thonny or your REPL IDE, copy `firmware/main.py` to the board as `/main.py`.
3. Restart. The firmware writes diagnostics to the USB serial REPL. It does not automatically become USB MIDI.
4. Configure pins in `firmware/main.py` to match your wiring before connecting hardware.

## Important electrical safety
- Pico GPIO/ADC pins are **3.3 V maximum**. Never connect a 5 V signal directly to a GPIO/ADC.
- A CD/74HC4067 module powered at 3.3 V is preferred for Pico use. Confirm the module's signal range.
- LM324 output can approach its supply rails only imperfectly and can exceed Pico ADC limits if powered from 5 V. Use a divider/clamp/buffer and measure with a multimeter before connecting.
- Piezo sensors can create high-voltage spikes. Use input protection and a suitable resistor/clamp network.
- A simple peak/pulse-width estimate is not calibrated velocity. The supplied firmware maps peak ADC amplitude to MIDI velocity and reports pulse width for tuning.

## Pin defaults
- 4067 S0..S3: GP2, GP3, GP4, GP5
- 4067 SIG: GP26 / ADC0
- optional 10k sensitivity potentiometer wiper: GP27 / ADC1 (ends to 3V3 and GND)
- 4067 EN: GP6 (active-low on common modules; change `MUX_EN_ACTIVE_LOW` if needed)
- 4067 inputs C0..C15: pad conditioning circuit outputs
- USB serial: Pico USB connector

Each pad's analog front end must be designed so the mux signal remains between 0 and 3.3 V.

## Build APK in GitHub Actions (when local Android SDK is unavailable)
1. Create a new GitHub repository and upload/push the contents of this project folder (the `settings.gradle.kts` file must be at repository root).
2. Open the repository's **Actions** tab and run **Build Android APK** (or push to `main`/`master`).
3. When the workflow completes, open its run and download the `OctapadStudio-debug-apk` artifact. Extract it to obtain `app-debug.apk`.
4. This workflow compiles the source; it does not certify hardware or MIDI transport functionality.
