# Wiring reference

## 4067 to Pico 2 W
| 4067 module | Pico 2 W |
|---|---|
| S0 | GP2 |
| S1 | GP3 |
| S2 | GP4 |
| S3 | GP5 |
| EN | GP6 |
| SIG / COM | GP26 / ADC0 |
| VCC | 3V3 (only if your module supports 3.3 V) |
| GND | GND |
| C0..C15 | one conditioned analog output per pad |

10k sensitivity potentiometer: one end 3V3, other end GND, wiper GP27/ADC1.

## LM324 analog stages
- Use the LM324 stages as pad preamps/envelope/threshold stages according to your actual circuit.
- LM324 is not rail-to-rail. Supply and output range matter.
- Never connect a 5 V LM324 output directly to Pico ADC.
- Use a correctly calculated divider/protection stage and verify maximum output with a meter/scope. A generic 5.1 V divider is not automatically safe unless its resistor values and input range are known.
- Piezo elements need a suitable series resistor and clamps; do not connect bare piezos directly to GPIO.
- The firmware's `peak` and `width` are coarse measurements made by polling; scanning 16 mux channels can miss very short transients. For accurate velocity, use an envelope/peak-hold circuit or ADC/DMA sampling and calibrate against real strikes.
