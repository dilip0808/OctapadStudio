# Octapad Studio Pico 2 W firmware - MicroPython starter
# Multiplexer analog peak scanning + approximate velocity mapping.
# VERIFY ADC-safe analog front end before connecting.
from machine import Pin, ADC
import time

# 4067 address lines
S0 = Pin(2, Pin.OUT)
S1 = Pin(3, Pin.OUT)
S2 = Pin(4, Pin.OUT)
S3 = Pin(5, Pin.OUT)
EN = Pin(6, Pin.OUT)
SIG = ADC(26)          # ADC0 / GP26
SENS = ADC(27)         # ADC1 / GP27, 10k pot wiper

MUX_EN_ACTIVE_LOW = True
CHANNELS = 16
THRESHOLD_MIN = 90     # calibrate from idle readings
RETRIGGER_MS = 90
SCAN_SETTLE_US = 80
PULSE_THRESHOLD = 90
# MIDI note mapping for 16 inputs; edit to taste
MIDI_NOTES = [36, 38, 42, 46, 41, 43, 45, 47, 48, 50, 43, 45, 49, 51, 53, 55]

last_hit = [0] * CHANNELS
noise_floor = [0] * CHANNELS
peak_seen = [0] * CHANNELS

def mux_enable(enabled):
    # Most 4067 modules use active-low EN.
    if MUX_EN_ACTIVE_LOW:
        EN.value(0 if enabled else 1)
    else:
        EN.value(1 if enabled else 0)

def select_channel(ch):
    S0.value(ch & 1)
    S1.value((ch >> 1) & 1)
    S2.value((ch >> 2) & 1)
    S3.value((ch >> 3) & 1)
    time.sleep_us(SCAN_SETTLE_US)

def sensitivity_threshold():
    # Pot high = more sensitive (lower threshold), low = less sensitive.
    raw = SENS.read_u16()
    return int(THRESHOLD_MIN + (raw * 900 // 65535))

def midi_velocity(peak, threshold):
    # Nonlinear approximate amplitude-to-velocity mapping.
    span = max(1, 65535 - threshold)
    v = 1 + int(max(0, min(1.0, (peak - threshold) / span)) ** 0.55 * 126)
    return max(1, min(127, v))

def read_peak(ch, threshold):
    select_channel(ch)
    # Sample a short window and estimate pulse width above threshold.
    peak = 0
    width = 0
    start = time.ticks_us()
    while time.ticks_diff(time.ticks_us(), start) < 2500:
        val = SIG.read_u16()
        if val > peak:
            peak = val
        if val > threshold:
            width += 1
    return peak, width

def emit_event(ch, velocity, peak, width):
    # Diagnostic event format for USB serial / IDE.
    # Not USB MIDI: standard MicroPython USB CDC is serial.
    print("HIT,{},{},{},{}".format(ch, MIDI_NOTES[ch], velocity, peak))
    print("DBG,{},{},{}".format(ch, peak, width))

def main():
    mux_enable(True)
    print("OCTAPAD_STUDIO_READY,channels={},firmware=0.1".format(CHANNELS))
    while True:
        threshold = sensitivity_threshold()
        for ch in range(CHANNELS):
            peak, width = read_peak(ch, threshold)
            now = time.ticks_ms()
            # Basic trigger; analog conditioning and thresholds are installation-specific.
            if peak > threshold and time.ticks_diff(now, last_hit[ch]) > RETRIGGER_MS:
                velocity = midi_velocity(peak, threshold)
                emit_event(ch, velocity, peak, width)
                last_hit[ch] = now
                peak_seen[ch] = peak
        time.sleep_ms(1)

try:
    main()
except KeyboardInterrupt:
    mux_enable(False)
    print("Octapad stopped.")
