# OPTIONAL / EXPERIMENTAL: basic TCP command receiver for a trusted local network.
# This is NOT a secure general-purpose remote Python shell.
# Do not expose this port to the internet. Use only on a private Wi-Fi network.
# This receiver executes arbitrary Python if exec() is uncommented: use caution.
# For safety, this example only accepts simple line commands and prints them.
import network, socket, time
SSID = "YOUR_WIFI_SSID"
PASSWORD = "YOUR_WIFI_PASSWORD"
PORT = 8266

wlan = network.WLAN(network.STA_IF)
wlan.active(True)
wlan.connect(SSID, PASSWORD)
while not wlan.isconnected():
    time.sleep_ms(250)
print("Wi-Fi:", wlan.ifconfig())
server = socket.socket()
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server.bind(("0.0.0.0", PORT))
server.listen(1)
print("TCP console ready on", PORT)
while True:
    client, addr = server.accept()
    print("Client:", addr)
    try:
        f = client.makefile("rwb")
        f.write(b"Octapad TCP line console; received lines are logged, not executed.\\r\\n")
        f.flush()
        while True:
            line = f.readline()
            if not line:
                break
            print("TCP:", line.decode("utf-8", "replace").strip())
            f.write(b"OK\\r\\n")
            f.flush()
    except Exception as e:
        print("TCP client error:", e)
    finally:
        client.close()
